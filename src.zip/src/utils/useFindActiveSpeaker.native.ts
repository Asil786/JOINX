const useFindActiveSpeaker = () => {
  return null;
};
export default useFindActiveSpeaker;
