import {nanoid} from 'nanoid/non-secure';

export default function getUniqueID() {
  return nanoid();
}
