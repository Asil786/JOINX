export function useOrientation() {
  return 'PORTRAIT';
}
