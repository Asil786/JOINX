const useIsLocalUserSpeaking = () => {
  return false;
};
export default useIsLocalUserSpeaking;
