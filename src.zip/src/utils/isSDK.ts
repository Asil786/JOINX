const isSDK = () => {
  return false;
}

export default isSDK;
