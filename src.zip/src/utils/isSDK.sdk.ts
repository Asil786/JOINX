const isSDK = () => {
  return true;
}

export default isSDK;
