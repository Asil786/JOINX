/**
 * Checks whether the application is running as a web application on a mobile or tablet device and returns true/false.
 * @returns function
 */
const isMobileOrTablet = () => {
  return true;
};

export default isMobileOrTablet;
