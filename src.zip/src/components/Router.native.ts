 
export {
  NativeRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useHistory,
  useParams,
  BackButton,
  useLocation,
  Prompt,
} from 'react-router-native';
