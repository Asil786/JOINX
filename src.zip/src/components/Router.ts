 
export {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useHistory,
  useParams,
  useLocation,
  Prompt,
} from 'react-router-dom';
