import React from 'react';

const StartScreenSharePopup = () => {
  return <></>;
};
export default StartScreenSharePopup;
