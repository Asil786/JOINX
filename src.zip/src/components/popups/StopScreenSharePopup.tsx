import React from 'react';

const StopScreenSharePopup = () => {
  return <></>;
};
export default StopScreenSharePopup;
