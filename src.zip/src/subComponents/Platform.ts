 
// utility to detect the appropriate platform.
// When one imports Platform module, the correct platform gets imported from
// either Platform.tsx or Platform.electron.tsx or Platform.native.tsx
export default 'web';
