 
/**
 * Empty component. There is illustraion on mobile devices
 */
const Illustration = () => {
  return {};
};

export default Illustration;
