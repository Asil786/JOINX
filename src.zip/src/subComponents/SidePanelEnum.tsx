 
export enum SidePanelType {
  None = 'None',
  Participants = 'Participants',
  Chat = 'Chat',
  Settings = 'Settings',
  Transcript = 'Transcript',
  VirtualBackground = 'VirtualBackground',
}
