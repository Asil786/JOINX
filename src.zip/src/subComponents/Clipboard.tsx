 
/**
 * On web and electron web, we use the clipbord component from the react-native-web library
 */
import {Clipboard} from 'react-native';

export default Clipboard;
