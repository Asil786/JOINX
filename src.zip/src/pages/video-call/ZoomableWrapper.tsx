import React from 'react';
const ZoomableWrapper = (props) => {
  return <>{props.children}</>;
};
export default ZoomableWrapper;
