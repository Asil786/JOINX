import Events from './Events';

export * from './types';

const events = new Events();
export default events;
