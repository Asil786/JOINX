 
import React, {useContext} from 'react';
import {Router} from './components/Router';
import Navigation from './components/Navigation';
import {StorageProvider} from './components/StorageContext';
import {SessionProvider} from './components/SessionContext';
import {
  ImageBackground,
  SafeAreaView,
  StatusBar,
  Platform,
  View,
} from 'react-native';
import ColorConfigure from './components/ColorConfigure';
import {isValidReactComponent} from './utils/common';
import DimensionProvider from './components/dimension/DimensionProvider';
import Error from './components/common/Error';
import {ErrorProvider} from './components/common';
import {useCustomization} from 'customization-implementation';
import {LanguageProvider} from './language/useLanguage';
import {AuthProvider} from './auth/AuthProvider';
import {PropsConsumer} from 'agora-rn-uikit';
import ToastComponent from './components/ToastComponent';
import {ToastContext, ToastProvider} from './components/useToast';
import {SdkApiContext} from './components/SdkApiContext';
import isSDK from './utils/isSDK';
import BlockUI from './subComponents/BlockUI';

interface AppWrapperProps {
  children: React.ReactNode;
}

const ImageBackgroundComp = (props: {
  bg?: string;
  color?: string;
  children?: React.ReactNode;
}) => {
  if (props?.bg) {
    return (
      <ImageBackground
        source={{uri: props.bg}}
        style={{flex: 1}}
        resizeMode={'cover'}>
        {props.children}
      </ImageBackground>
    );
  } else if (props?.color) {
    return (
      <View style={{flex: 1, backgroundColor: props.color}}>
        {props.children}
      </View>
    );
  } else {
    return <>{props.children}</>;
  }
};

const AppWrapper = (props: AppWrapperProps) => {
  const AppRoot = useCustomization(data => {
    if (
      data?.components?.appRoot &&
      isValidReactComponent(data?.components?.appRoot)
    ) {
      return data.components.appRoot;
    }
    return React.Fragment;
  });

  const {join: SdkJoinState} = useContext(SdkApiContext);

  return (
    <AppRoot>
      <ImageBackgroundComp bg={$config.BG} color={$config.BACKGROUND_COLOR}>
        <SafeAreaView
          // @ts-ignore textAlign not supported by TS definitions but is applied to web regardless
          style={[{flex: 1}, Platform.select({web: {textAlign: 'left'}})]}>
          <StatusBar backgroundColor={$config.BACKGROUND_COLOR} />
          {$config.DISABLE_LANDSCAPE_MODE && <BlockUI />}
          <StorageProvider>
            <LanguageProvider>
              <Router
                /*@ts-ignore Router will be memory Router in sdk*/
                initialEntries={[
                  //@ts-ignore
                  isSDK && SdkJoinState.phrase
                    ? //@ts-ignore
                      `/${SdkJoinState.phrase}`
                    : '',
                ]}>
                <ToastProvider>
                  <ToastContext.Consumer>
                    {({isActionSheetVisible}) => {
                      return !isActionSheetVisible ? <ToastComponent /> : null;
                    }}
                  </ToastContext.Consumer>
                  <AuthProvider>
                    <SessionProvider>
                      <ColorConfigure>
                        <DimensionProvider>
                          <ErrorProvider>
                            <Error />
                            <Navigation />
                            {props.children}
                          </ErrorProvider>
                        </DimensionProvider>
                      </ColorConfigure>
                    </SessionProvider>
                  </AuthProvider>
                </ToastProvider>
              </Router>
            </LanguageProvider>
          </StorageProvider>
        </SafeAreaView>
      </ImageBackgroundComp>
    </AppRoot>
  );
  // return <div> hello world</div>; {/* isn't join:phrase redundant now, also can we remove joinStore */}
};

export default AppWrapper;
